<?php
$name= $_POST['Name'];
$email=$_POST['Email'];
$age=$_POST['age'];
echo "Nmae is ".$name."</br>";
echo "Email is ".$email."</br>";
echo "Age is ".$age."</br>";

$conn = new mysqli("localhost","root","","wed");
$q= "insert into info(`std_name`,`std_email`,`std_age`) values( '".$name."','".$email."',".$age.")";
$conn-> query($q);
?>