<?php
$id = $_GET['id'];
$conn = new mysqli("localhost","root","","wed");
$q= "DELETE From info where std_id= ".$id;
if($conn->query($q) === TRUE)
{
    header("Location:index.php");
}
?>