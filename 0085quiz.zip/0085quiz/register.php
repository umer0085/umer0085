<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
	<form method="POST" action="information.php">
		Name:<input type="text" name="stdName" placeholder="Enter Student Name"> <br>
        Father Name:<input type="text" name="std_father_Name" placeholder="Enter Father Name"> <br>
        Address:<input type="text" name="std_address" placeholder="Enter Address"> <br>
        Parmanent Address:<input type="text" name="std_par_address" placeholder="Enter Address">
        <br>
        Program Register <br>
        <input type="radio" id="prog regis" name="program" value="HTML">
         <label for="html">BBA</label><br>
         <input type="radio" id="css" name="program" value="CSS">
         <label for="css">MBA</label><br>
         <input type="radio" id="javascript" name="program" value="JavaScript">
         <label for="javascript">BSCS</label>
         <br>
          Additional Facilities Required
          <br>
          <input type="checkbox" id="fac1" name="facility" >
  <label for="fac1"> Sports Gymnasium</label><br>
  <input type="checkbox" id="fac2" name="facility" >
  <label for="fac2"> Travel with University Bus Service</label><br>
  <input type="checkbox" id="fac3" name="facility" >
  <label for="fac3"> University Hostel Accomodation</label><br><br>
  <input type="submit" value="Submit">
	</form>
</body>
</html>