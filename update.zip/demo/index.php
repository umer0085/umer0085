<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Demo</title>
</head>
<body>
    <form action="insert.php" method="post">
        <input type="text" name="Name" placeholder="Name">
        <input type="text" name="Email" placeholder="Email">
        <input type="int" name="age" placeholder="Age">
        <input type="submit" value="Submit">
        
    </form>
    <?php
    $conn = new mysqli("localhost","root","","wed");
    $q= "Select * From info";
    $ds= $conn-> query($q);
    echo'<table style border=1>';
    while($row= $ds->fetch_assoc())
    {
        echo "<tr>";
        echo "<td>";
        echo $row['std_id'];
        echo "</td>";
        echo "<td>";
        echo $row['std_name'];
        echo "</td>";
        echo"<td>";
        echo $row['std_email'];
        echo"</td>";
        echo "<td>";
        echo "<a href = 'delete.php?id=".$row['std_id']."'>";
        echo "Delete";
        echo "</a>";
        echo"</td>";
        echo "<td>";
        echo "<a href = 'update.php?id=".$row['std_id']."'>";
        echo "Update";
        echo "</a>";
        echo"</td>";
        echo "</tr>";
    }
    echo'<tTable>';
    ?>
</body>
</html>