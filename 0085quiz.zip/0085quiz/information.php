<?php
$name = $_POST['stdName'];
$f_name = $_POST['std_father_Name'];
$address = $_POST['std_address'];
$parmanemt_add=$_POST['std_par_address'];
$program=$_POST['program'];
$facility=$_POST['facility'];
$conn = new mysqli("localhost","root","","register");
$q = "INSERT INTO `stdinfo`(`std_name`, `std_father_name`, `std_address`, `std_parm_addres`, `std_prog`, `std_facility`) VALUES ('".$name."','".$f_name."','".$address."','".$parmanemt_add."','".$program."','".$facility."') ";
$result =$conn->query($q);
if($result==true){
    echo "success";
}else{
	echo $result->error;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
echo"<table border='1'>";
echo "<tr>";
		echo"<th>";
		echo "Name";
	echo"</th>";
	echo"<th>";
		echo " Father Name";
	echo"</th>";

		echo"<th>";
		echo "Address";
	echo"</th>";
    echo"<th>";
		echo "Parmanent Address";
	echo"</th>";

    echo"<th>";
		echo "Program";
	echo"</th>";

    echo"<th>";
		echo "Facility";
	echo"</th>";
echo "</tr>";

while($row = $result->fetch_assoc()) {
	echo "<tr>";

		echo"<td>";
			echo $row["stdName"];
		echo"</td>";

			echo"<td>";
			echo $row["std_father_name"];
		echo"</td>";

			echo"<td>";
			echo $row["std_address"];
		echo"</td>";
        echo"<td>";
			echo $row["std_parm_addres"];
		echo"</td>";

        echo"<td>";
			echo $row["std_prog"];
		echo"</td>";
        echo"<td>";
			echo $row["std_facility"];
		echo"</td>"; 
	echo"</tr>";
}

echo"</table>";

?>
</body>
</html>